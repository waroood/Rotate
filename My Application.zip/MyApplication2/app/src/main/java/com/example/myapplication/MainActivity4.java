package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.net.Uri;

public class MainActivity4 extends AppCompatActivity {
    ImageButton bt3;
    ImageButton bt4;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        bt3 = findViewById(R.id.imageButton3);
        bt4 = findViewById(R.id.imageButton4);
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_DIAL);
                myIntent.setData(Uri.parse("tel:0512345678"));
                startActivity(myIntent);
            }
        } );

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_SENDTO);
                myIntent.setData(Uri.parse("mailto:rotate@gmail.com"));
                startActivity(myIntent);
            }
        } );

        ImageButton imgbtn =(ImageButton) findViewById(R.id.account);
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity4.this, MainActivity3.class);
                startActivity(myIntent1);
            }
        });

        ImageButton imgbtn1 =(ImageButton) findViewById(R.id.fav);
        imgbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity4.this, MainActivity.class);
                startActivity(myIntent1);
            }
        });

        ImageButton imgbtn2 =(ImageButton) findViewById(R.id.back);
        imgbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity4.this, MainActivity3.class);
                startActivity(myIntent1);
            }
        });
    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);


        EditText edt1 = (EditText) findViewById(R.id.usremail);
        edt1.setEnabled(false);
        Button btn1 = (Button) findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt1);
            }
        });

        EditText edt2 = (EditText) findViewById(R.id.usrname);
        edt2.setEnabled(false);
        Button btn2 = (Button) findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt2);
            }
        });

        EditText edt3 = (EditText) findViewById(R.id.username);
        edt3.setEnabled(false);
        Button btn3 = (Button) findViewById(R.id.btn3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt3);
            }
        });
        EditText edt4 = (EditText) findViewById(R.id.usrID);
        edt4.setEnabled(false);
        Button btn4 = (Button) findViewById(R.id.btn4);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt4);
            }
        });
        EditText edt5 = (EditText) findViewById(R.id.usrpass);
        edt5.setEnabled(false);
        Button btn5 = (Button) findViewById(R.id.btn5);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt5);
            }
        });
        ImageButton imgbtn = (ImageButton) findViewById(R.id.account);
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity5.this, MainActivity3.class);
                startActivity(myIntent1);
            }
        });

        ImageButton imgbtn1 = (ImageButton) findViewById(R.id.fav);
        imgbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity5.this, MainActivity.class);
                startActivity(myIntent1);
            }
        });

        ImageButton imgbtn2 = (ImageButton) findViewById(R.id.back2);
        imgbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent1 = new Intent(MainActivity5.this, MainActivity3.class);
                startActivity(myIntent1);
            }
        });

    }



    public void editable(EditText edt){
        if(edt.getKeyListener() != null){
            edt.setEnabled(false);
            edt.setTag(edt.getKeyListener());
            edt.setKeyListener(null);
        } else {
            edt.setEnabled(true);
            edt.setKeyListener((KeyListener) edt.getTag());
        }
    }
}
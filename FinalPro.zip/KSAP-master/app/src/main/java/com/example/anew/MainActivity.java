package com.example.anew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.MainyActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    TextView textView8;
    TextView textView4;

    private EditText userNameEdit;
    private EditText userPassword;
    private Button signInButton;
    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.anew.R.layout.activity_main);

        userNameEdit = findViewById(com.example.anew.R.id.UserName);
        userPassword = findViewById(com.example.anew.R.id.Password);
        signInButton = findViewById(com.example.anew.R.id.SignInBtn);
        progressBar = findViewById(com.example.anew.R.id.progressBar);
        textView = (TextView) findViewById(R.id.textView);
        textView8 = (TextView) findViewById(R.id.textView8);
        textView4 = (TextView) findViewById(R.id.textView4);



        firebaseAuth = FirebaseAuth.getInstance();

        textView8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity1();
            }
        });


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity2();
            }
        });

       /* textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity4();
            }
        });*/


        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = userNameEdit.getText().toString();
                String pass = userPassword.getText().toString();

                if(TextUtils.isEmpty(email)){
                    Toast.makeText(MainActivity.this,"يرجى ادخال الايميل",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    Toast.makeText(MainActivity.this,"يرجى ادخال الرقم السري",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(pass.length() < 6){
                    Toast.makeText(MainActivity.this,"الرقم السري لا يكمن ان يكون اقل من 6 حروف",Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                firebaseAuth
                        .signInWithEmailAndPassword(email,pass)
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                if(authResult.getUser() != null){
                                    progressBar.setVisibility(View.GONE);
                                    // go to main page
                                    Toast.makeText(MainActivity.this,"تم تسجيل الدخول بنجاح",Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(MainActivity.this, MainyActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // error
                                progressBar.setVisibility(View.GONE);
                            }
                        });

            }
        });

    }


    public void openNewActivity1(){
        Intent intent = new Intent(this, SignUpPAge.class);
        startActivity(intent);
    }

    public void openNewActivity2(){
        Intent intent = new Intent(this, ForgetPassword.class);
        startActivity(intent);
    }
    /*public void openNewActivity4(){
        Intent intent = new Intent(this, ForgetPassword.class);
        startActivity(intent);
    }*/
    }

package com.example.anew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import android.app.Activity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.example.myapplication.MainyActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class SignUpPAge extends AppCompatActivity {
    ImageView imageView5;
    RadioGroup radioGroup;

    Button signUp;
    RadioButton genderradioButton;

    RadioButton female;
    RadioButton male;


    private EditText signUpUser;
    private EditText userEmail;
    private EditText userID;
    private EditText userPhone;
    private EditText userBirthDay;
    private EditText userPass;
    private EditText confirmUserPass;

    private Button signUpButton;
    private String selectedGender = "";
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private ProgressBar progressBar;
    private Calendar myCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);
        signUpUser = findViewById(R.id.SignUpUser);
        userEmail  = findViewById(R.id.Email);
        userID = findViewById(R.id.ID);
        userPhone = findViewById(R.id.Phone);
        userBirthDay = findViewById(R.id.birthDay);
        userPass = findViewById(R.id.Pass);
        confirmUserPass = findViewById(R.id.ConfPass);
        signUpButton = findViewById(R.id.SignUpBtn);
        imageView5 = (ImageView) findViewById(R.id.imageView5);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        progressBar = findViewById(R.id.progressBar);
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity3();
            }
        });

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        // register new user
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = signUpUser.getText().toString();
                String email = userEmail.getText().toString();
                String ID = userID.getText().toString();
                String phone = userPhone.getText().toString();
                String birthDay = userBirthDay.getText().toString();
                String pass = userPass.getText().toString();
                String confirmPass = confirmUserPass.getText().toString();

                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال الاسم الكامل ",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(email)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال الايميل",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(ID)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال رقم الهوية",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(phone)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال رقم الهاتف",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(birthDay)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال تاريخ الميلاد",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    Toast.makeText(SignUpPAge.this,"يرجى ادخال الرقم السري ",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(pass.length() < 6){
                    Toast.makeText(SignUpPAge.this,"الرقم السري لا يكمن ان يكون اقل من 6 حروف",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(confirmPass)){
                    Toast.makeText(SignUpPAge.this,"يرجى تاكيد الرقم السري ",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(Objects.equals(selectedGender, "")){
                    Toast.makeText(SignUpPAge.this,"يرجى اختيار الجنس ",Toast.LENGTH_SHORT).show();
                    return;
                }

                if(pass.toString().trim().equals(confirmPass.toString().trim())){
                    progressBar.setVisibility(View.VISIBLE);
                    firebaseAuth
                            .createUserWithEmailAndPassword(email,pass)
                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                @Override
                                public void onSuccess(AuthResult authResult) {
                                    if(authResult.getUser() != null){
                                        // push user data into database
                                        Map<String,Object> map = new HashMap<>();
                                        map.put("userName",userName);
                                        map.put("email",email);
                                        map.put("ID",ID);
                                        map.put("phone",phone);
                                        map.put("birthday",birthDay);
                                        map.put("gender",selectedGender);

                                        firebaseDatabase
                                                .getReference()
                                                .child("Users")
                                                .child(Objects.requireNonNull(firebaseAuth.getUid()))
                                                .setValue(map)
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        progressBar.setVisibility(View.GONE);
                                                        Toast.makeText(SignUpPAge.this,"تم تسجيل حساب جديد بنجاح",Toast.LENGTH_SHORT).show();
                                                        Intent intent = new Intent(SignUpPAge.this, MainyActivity.class);
                                                        startActivity(intent);
                                                        finish();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        progressBar.setVisibility(View.GONE);
                                                    }
                                                });
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    progressBar.setVisibility(View.GONE);
                                }
                            });
                } else {
                    Toast.makeText(SignUpPAge.this,"كلة السر غير متطابقة ",Toast.LENGTH_SHORT).show();
                }
            }
        });
        myCalendar = Calendar.getInstance();

        userBirthDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        // GET USER GENDER
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = findViewById(checkedId);
                selectedGender = radioButton.getText().toString();
                // Do something with the selected value
            }
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateBirthdayEditText();
            }
        };

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                dateSetListener,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.show();
    }

    private void updateBirthdayEditText() {
        String myFormat = "dd/MM/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.getDefault());
        userBirthDay.setText(sdf.format(myCalendar.getTime()));
    }
    public void openNewActivity3(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
package com.example.anew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;


public class ForgetPassword extends AppCompatActivity {
    ImageView imageView2;
    private EditText emailEdit;
    private Button recoverPass;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        imageView2 = (ImageView) findViewById(R.id.imageView2);
        emailEdit = findViewById(R.id.emailEditText);
        recoverPass = findViewById(R.id.recoverPass);

        firebaseAuth = FirebaseAuth.getInstance();
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity4();
            }
        });

        recoverPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEdit.getText().toString();
                if(TextUtils.isEmpty(email)){
                    Toast.makeText(ForgetPassword.this,"يرجى ادخال الايميل",Toast.LENGTH_SHORT).show();
                    return;
                }

                firebaseAuth
                        .sendPasswordResetEmail(email)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(ForgetPassword.this,"يرجى ارسال ايميل لاسترجاع الرقم السري",Toast.LENGTH_SHORT).show();
                                emailEdit.getText().clear();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
            }
        });
    }
    public void openNewActivity4(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    }

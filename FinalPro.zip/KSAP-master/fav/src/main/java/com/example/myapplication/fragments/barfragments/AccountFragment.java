package com.example.myapplication.fragments.barfragments;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.myapplication.MainActivity2;
import com.example.myapplication.MainActivity4;
import com.example.myapplication.MainyActivity;
import com.example.myapplication.R;

public class AccountFragment extends Fragment {
    private TextView textview6;
    Dialog Mydialog;
    Button cancel;
    private ImageButton imgbtn;
    private androidx.cardview.widget.CardView tbrvar;
    androidx.cardview.widget.CardView callvar;
    ImageButton imgbtn1;
    private View v;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.account_fragment_layout,container,false);
        textview6 = (TextView) v.findViewById(R.id.textView6);
        callvar = (CardView) v.findViewById(R.id.call1);
        tbrvar = (CardView) v.findViewById(R.id.tbr1);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        textview6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });




        tbrvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(requireContext(), MainActivity2.class);
                startActivity(myIntent);
            }
        });
        callvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(requireContext(), MainActivity4.class);
                startActivity(myIntent);
            }
        });
    }

    public void openDialog(){
        Mydialog = new Dialog(requireContext());
        Mydialog.setContentView(R.layout.imagedialog);
        Mydialog.setTitle("لما تزرع تحصل على: ");

        cancel = (Button)Mydialog.findViewById(R.id.cancel);

        cancel.setEnabled(true);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Mydialog.cancel();
            }
        });
        Mydialog.show();
    }
}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);


        EditText edt =(EditText) findViewById(R.id.name) ;
        edt.setEnabled(false);
        Button btn =(Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editable(edt);
            }
        });

    }

    public void editable(EditText edt){
        if(edt.getKeyListener() != null){
            edt.setEnabled(true);
            edt.setTag(edt.getKeyListener());
            edt.setKeyListener(null);
        } else {
            edt.setKeyListener((KeyListener) edt.getTag());
        }
    }
}
package com.example.myapplication.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.adapters.DecorAdapter;
import com.example.myapplication.adapters.models.DecorModel;

import java.util.ArrayList;

public class DecorFragment  extends Fragment {

    private RecyclerView recyclerView;
    private DecorAdapter decorAdapter;
    private ArrayList<DecorModel> arrayList;
    private View v;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       v = inflater.inflate(R.layout.decor_fragment_layout,container,false);
       recyclerView = v.findViewById(R.id.recyclerView);
       return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        arrayList = new ArrayList<>();
        arrayList.add(new DecorModel(R.drawable.sofa,"اثاث"));
        arrayList.add(new DecorModel(R.drawable.electro,"الكترونيات"));
        arrayList.add(new DecorModel(R.drawable.books,"كتب"));
        arrayList.add(new DecorModel(R.drawable.clothes,"ملابس"));


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(),LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);

        decorAdapter = new DecorAdapter(arrayList);
        recyclerView.setAdapter(decorAdapter);
    }
}

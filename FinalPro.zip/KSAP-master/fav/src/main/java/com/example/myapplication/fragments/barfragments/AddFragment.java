package com.example.myapplication.fragments.barfragments;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.extras.DatabaseHelper;
import com.example.myapplication.extras.Product;
import com.example.myapplication.extras.ProductAdapter;
import com.example.myapplication.ui.ProductActivity;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class AddFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 123;
    private DatabaseHelper databaseHelper;
    private ImageView selectedImageView;
    private byte[] selectedImageBytes;
    private View v;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.add_fragment_layout,container,false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(getActivity());

        // Get references to the views
        EditText productNameEditText = view.findViewById(R.id.productNameEditText);
        Spinner categorySpinner = view.findViewById(R.id.categorySpinner);
        Spinner areaSpinner = view.findViewById(R.id.areaSpinner);
        EditText descriptionEditText = view.findViewById(R.id.descriptionEditText);
        Button imageButton = view.findViewById(R.id.imageButton);
        selectedImageView = view.findViewById(R.id.selectedImageView);
        Button saveButton = view.findViewById(R.id.saveButton);

        // Set click listener for the image button
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to open the image gallery
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        // Set click listener for the save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the values from the views
                String productName = productNameEditText.getText().toString();
                String category = categorySpinner.getSelectedItem().toString();
                String area = areaSpinner.getSelectedItem().toString();
                String description = descriptionEditText.getText().toString();

                // Create a new Product object with the values
                Product product = new Product();
                product.setName(productName);
                product.setCategory(category);
                product.setArea(area);
                product.setDescription(description);
                product.setImage(selectedImageBytes);

                // Add the product to the database
                long id = databaseHelper.addProduct(product);

                // TODO: Perform any additional actions after saving the product

                // Clear the input fields and selected image
                productNameEditText.setText("");
                descriptionEditText.setText("");
                selectedImageView.setImageResource(R.drawable.ic_img);
                selectedImageBytes = null;

                // Show a toast message indicating the product was saved
                Toast.makeText(getActivity(), "Product saved with ID: " + id, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(requireContext(), ProductActivity.class);
                startActivity(intent);
            }
        });

    }

    // Override onActivityResult to handle the selected image
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // Get the selected image URI
            Uri imageUri = data.getData();

            try {
                // Convert the selected image to a byte array
                InputStream inputStream = getActivity().getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                selectedImageBytes = byteArrayOutputStream.toByteArray();

                // Set the selected image in the ImageView
                selectedImageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}

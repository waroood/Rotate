package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity3 extends AppCompatActivity {
    private TextView textview6;
    Dialog Mydialog;
    Button cancel;

    private ImageButton imgbtn;

    private androidx.cardview.widget.CardView tbrvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textview6 = (TextView) findViewById(R.id.textView6);
        textview6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });


        androidx.cardview.widget.CardView tbrvar = (CardView) findViewById(R.id.tbr1);

        tbrvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(myIntent);
            }
        });

        androidx.cardview.widget.CardView callvar = (CardView) findViewById(R.id.call1);

        callvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity3.this, MainActivity4.class);
                startActivity(myIntent);
            }
        });


    }
    public void openDialog(){
        Mydialog = new Dialog(MainActivity3.this);
        Mydialog.setContentView(R.layout.imagedialog);
        Mydialog.setTitle("لما تزرع تحصل على: ");

        cancel = (Button)Mydialog.findViewById(R.id.cancel);

        cancel.setEnabled(true);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Mydialog.cancel();
            }
        });
        Mydialog.show();
    }
}
package com.example.myapplication.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.extras.DatabaseHelper;
import com.example.myapplication.extras.Product;
import com.example.myapplication.extras.ProductAdapter;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ProductActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private TextView noDataTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        recyclerView = findViewById(R.id.recyclerView);
        noDataTextView = findViewById(R.id.noDataTextView);

        // Configure the RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductAdapter(new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);



        // Load the products from the database
        loadProducts();
    }

    private void loadProducts() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        List<Product> productList = dbHelper.getAllProducts();

        // Check if there are no products
        if (productList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            noDataTextView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            noDataTextView.setVisibility(View.GONE);

            adapter = new ProductAdapter(productList,this);
            recyclerView.setAdapter(adapter);
        }
    }
}
package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.example.myapplication.fragments.BookFragment;
import com.example.myapplication.fragments.ClothesFragment;
import com.example.myapplication.fragments.DecorFragment;
import com.example.myapplication.fragments.ElectronicsFragment;
import com.example.myapplication.fragments.barfragments.AccountFragment;
import com.example.myapplication.fragments.barfragments.AddFragment;
import com.example.myapplication.fragments.barfragments.ChatFragment;
import com.example.myapplication.fragments.barfragments.FavFragment;
import com.example.myapplication.fragments.barfragments.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.tabs.TabLayout;

public class MainyActivity extends AppCompatActivity {

    private BottomNavigationView navigationView;
    private FloatingActionButton fab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainy);
        navigationView = findViewById(R.id.nav);
        fab  = findViewById(R.id.fab);

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new HomeFragment()).commit();

        navigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.account){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new AccountFragment()).commit();
                }
                else if (item.getItemId() == R.id.add){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new AddFragment()).commit();
                } else if (item.getItemId() == R.id.fav){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new FavFragment()).commit();
                } else if(item.getItemId() ==  R.id.home){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new HomeFragment()).commit();
                }
                return false;
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new AddFragment()).commit();
            }
        });

    }
}
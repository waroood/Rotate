package com.example.myapplication.fragments.barfragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.fragments.BookFragment;
import com.example.myapplication.fragments.ClothesFragment;
import com.example.myapplication.fragments.DecorFragment;
import com.example.myapplication.fragments.ElectronicsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

public class HomeFragment extends Fragment {

    private TabLayout tabLayout;
    private View v;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.home_fragment_layout,container,false);
        tabLayout = v.findViewById(R.id.tabLayout);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        if(savedInstanceState == null){
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeFrameLayout,new DecorFragment()).commit();
        }

        tabLayout.addTab(tabLayout.newTab().setText("اثاث و ديكور"));
        tabLayout.addTab(tabLayout.newTab().setText("الكترونيات"));
        tabLayout.addTab(tabLayout.newTab().setText("كتب"));
        tabLayout.addTab(tabLayout.newTab().setText("ملابس"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if(tab.getPosition() == 0){
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeFrameLayout,new DecorFragment()).commit();
                } else if (tab.getPosition() == 1){
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeFrameLayout,new ElectronicsFragment()).commit();
                } else if (tab.getPosition() == 2){
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeFrameLayout,new BookFragment()).commit();
                } else if(tab.getPosition() == 3){
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeFrameLayout,new ClothesFragment()).commit();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



    }
}
